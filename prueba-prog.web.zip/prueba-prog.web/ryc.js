document.addEventListener('DOMContentLoaded', function () {
    const formulario = document.querySelector('form');
    formulario.addEventListener('submit', function (event) {
        event.preventDefault();
        
        const mensajeProcesando = document.createElement('div');

        // mostramos mensaje
        mensajeProcesando.textContent = 'Procesando...';
        mensajeProcesando.classList.add('alert', 'alert-info', 'mt-3');
        formulario.appendChild(mensajeProcesando);

        setTimeout(() => {
            formulario.removeChild(mensajeProcesando);

            alert('El formulario ha sido enviado exitosamente.');

            // reseteamos el formulario
            formulario.reset();
        }, 800);
    });
});

// pausamos el carrusel
$('#carousel-principal').carousel({
    pause: "hover"
});
